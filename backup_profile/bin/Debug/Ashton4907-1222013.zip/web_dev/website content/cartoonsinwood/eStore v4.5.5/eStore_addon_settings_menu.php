<?php

function wp_eStore_addon_settings()
{
    if (isset($_POST['info_update']))
    {
        update_option('eStore_aff_allow_aff_id', ($_POST['eStore_aff_allow_aff_id']=='1') ? '1':'' );
        update_option('eStore_aff_link_coupon_aff_id', ($_POST['eStore_aff_link_coupon_aff_id']=='1') ? '1':'' ); 
        update_option('eStore_aff_one_time_commission', ($_POST['eStore_aff_one_time_commission']=='1') ? '1':'' ); 
        update_option('eStore_aff_enable_revenue_sharing', ($_POST['eStore_aff_enable_revenue_sharing']=='1') ? '1':'' ); 

        update_option('eStore_eMember_must_be_logged_to_checkout', ($_POST['eStore_eMember_must_be_logged_to_checkout']=='1') ? '1':'' );
        update_option('eStore_eMember_redirection_url_when_not_logged', (string)$_POST["eStore_eMember_redirection_url_when_not_logged"]);
        
	eStore_dlmgradm::settings_menu_post($_POST['eStore_auto_convert_to_relative_url'], $_POST['eStore_download_method']);
        
        update_option('eStore_lic_mgr_post_url', (string)$_POST["eStore_lic_mgr_post_url"]);
        update_option('eStore_lic_mgr_secret_word', (string)$_POST["eStore_lic_mgr_secret_word"]);
                
        echo '<div id="message" class="updated fade"><p><strong>';
        echo 'Options Updated!';
        echo '</strong></p></div>';
    }
    $defaultEmail = get_option('cart_paypal_email');
    if (empty($defaultEmail)) $defaultEmail = get_bloginfo('admin_email');
    
	?>
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="info_update" id="info_update" value="true" />

	<div class="postbox">
	<h3><label for="title">WP Affiliate Platform Plugin Specific Settings</label></h3>
	<div class="inside">

    Only use these options if you are using the <a href="http://www.tipsandtricks-hq.com/?p=1474" target="_blank">WP Affiliate Platform Plugin</a>
    <br /><br />

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    Allow Affiliate ID Entry 
    </td><td align="left">
    <input name="eStore_aff_allow_aff_id" type="checkbox"<?php if(get_option('eStore_aff_allow_aff_id')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will give the customer an option to enter an "Affiliate ID" in the shopping cart to give reward to an affiliate</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Link Affiliate ID with Coupons Table 
    </td><td align="left">
    <input name="eStore_aff_link_coupon_aff_id" type="checkbox"<?php if(get_option('eStore_aff_link_coupon_aff_id')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the customer entering an "Affiliate ID" in the shopping cart will also be able to receive a discount if there is a coupon code in the coupons table that matches with the Affiliate ID. Useful when trying to promote a special deal with an affiliate</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    One Time Commission for Subscription Payment 
    </td><td align="left">
    <input name="eStore_aff_one_time_commission" type="checkbox"<?php if(get_option('eStore_aff_one_time_commission')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will award commission only once for the subscription payment. Recurring payments will not award affiliate commission.</i><br /><br />
    </td></tr>            
    
    <tr valign="top"><td width="25%" align="left">
    Enable Revenue Sharing
    </td><td align="left">
    <input name="eStore_aff_enable_revenue_sharing" type="checkbox"<?php if(get_option('eStore_aff_enable_revenue_sharing')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will enable the revenue sharing feature. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=930" target="_blnak">Read More Here</a></i><br /><br />
    </td></tr>  
        
    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">WP eMember Plugin Specific Settings</label></h3>
	<div class="inside">

    Only use these options if you are using the <a href="http://www.tipsandtricks-hq.com/?p=1706" target="_blank">WP eMember Plugin</a>
    <br /><br />

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    Only Logged In Members Can Checkout 
    </td><td align="left">
    <input name="eStore_eMember_must_be_logged_to_checkout" type="checkbox"<?php if(get_option('eStore_eMember_must_be_logged_to_checkout')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will not allow an anonymous user to continue shopping cart checkout unless the user logs in or registers for an account in eMember.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Redirection URL for Anonymous Checkout
    </td><td align="left">
    <input name="eStore_eMember_redirection_url_when_not_logged" type="text" size="100" value="<?php echo get_option('eStore_eMember_redirection_url_when_not_logged'); ?>"/>
    <br /><i>When an anonymous user clicks the "Checkout" button in the shopping cart, the user will be reditected to this URL requesting him/her to log in or register for an account.</i><br /><br />
    </td></tr>        
    
    </table>
    </div></div>
    
<?php if (function_exists('wp_lic_manager_install')){ ?>
	<div class="postbox">
	<h3><label for="title">WP License Manager Plugin Specific Settings</label></h3>
	<div class="inside">

    Only use these options if you are using the <a href="http://www.tipsandtricks-hq.com/" target="_blank">WP License Manager Plugin</a>
    <br /><br />

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    License Creation POST URL 
    </td><td align="left">
    <input name="eStore_lic_mgr_post_url" type="text" size="100" value="<?php echo get_option('eStore_lic_mgr_post_url'); ?>"/>
    <br /><i>Get this value from the WP License Manager plugin's settings tab</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    License Creation Secret Word
    </td><td align="left">
    <input name="eStore_lic_mgr_secret_word" type="text" size="50" value="<?php echo get_option('eStore_lic_mgr_secret_word'); ?>"/>
    <br /><i>Get this value from the WP License Manager plugin's settings tab</i><br /><br />
    </td></tr>        
    
    </table>
    </div></div>
<?php } ?>
    
	<div class="postbox">
	<h3><label for="title">WP eStore Download Manager Related</label></h3>
	<div class="inside">

	<?php echo eStore_dlmgradm::settings_menu_html(); ?>
    </div></div>
        
    <div class="submit">
        <input type="submit" name="info_update" value="<?php _e('Update'); ?> &raquo;" />
    </div>
    </form>
    <?php
}

?>
