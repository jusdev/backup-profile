<?php
include_once('../../../wp-load.php');
include_once('email.php');
include_once('eStore_includes2.php');
include_once('eStore_includes4.php');
include_once('eStore_post_payment_processing_helper.php');
include_once('eStore_auto_responder_handler.php');

if ((isset($_POST['name'])) && (strlen(trim($_POST['name'])) > 0)) {
	$name = stripslashes(strip_tags($_POST['name']));
} else {$name = 'No name entered';}
if ((isset($_POST['email'])) && (strlen(trim($_POST['email'])) > 0)) {
	$email = stripslashes(strip_tags($_POST['email']));
} else {$email = 'No email entered';}
if ((isset($_POST['prod_id'])) && (strlen(trim($_POST['prod_id'])) > 0)) {
	$prod_id = stripslashes(strip_tags($_POST['prod_id']));
} else {$prod_id = 'No product id found';}

// These 2 lines of code ensure the Ajax version of the "squeeze form" now passes its data through to the PDF Stamper addon.
// -- The Assurer, 2010-09-12.
$payment_data = free_download_pseudo_payment_data($name, $email);		// Populate the pseudo payment data.
$download = generate_download_link_for_product($prod_id, '', $payment_data);	// Generate the download link.
//$download = generate_download_link_for_product($prod_id);

if (eStore_send_free_download1($name, $email, $download))
{
    //Aweber Signup
    global $wpdb;
    $customer_table_name = $wpdb->prefix . "wp_eStore_customer_tbl";
    $products_table_name = $wpdb->prefix . "wp_eStore_tbl";
    $retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$prod_id'", OBJECT);
    
    $download_email = get_option('eStore_download_email_address');

    // Autoresponder Sign up
    list($firstname,$lastname) = explode(' ',$name);   
    $cart_items = array();
	$current_item = array(
	          		'item_number' => $prod_id,
					'item_name' => $retrieved_product->name,
					);
	
	array_push($cart_items, $current_item);	  
	  
    eStore_item_specific_autoresponder_signup($cart_items,$firstname,$lastname,$email);                 
                
    // Update the Customer and products table table
	$cart_item_qty = 1;
    if (is_numeric($retrieved_product->available_copies))
    {
        $new_available_copies = ($retrieved_product->available_copies - $cart_item_qty);
    }
    $new_sales_count = ($retrieved_product->sales_count + $cart_item_qty);
    $current_product_id = $retrieved_product->id;
    $updatedb = "UPDATE $products_table_name SET available_copies = '$new_available_copies', sales_count = '$new_sales_count' WHERE id='$current_product_id'";
    $results = $wpdb->query($updatedb);    
     
    $emailaddress = $email;
    $name_pieces = explode(' ', $name);
	$firstname = $name_pieces[0];
    $clientdate = (date ("Y-m-d"));
    $txn_id = "Free Download";
    $sale_price = '0';
	if (!empty($name_pieces[1]))
		$lastname = $name_pieces[1];

    $ret_customer_db = $wpdb->get_results("SELECT email_address FROM $customer_table_name WHERE purchased_product_id = '$prod_id' and email_address='$emailaddress'", OBJECT);
    if (!$ret_customer_db)
	{
		$updatedb = "INSERT INTO $customer_table_name (first_name, last_name, email_address, purchased_product_id,txn_id,date,sale_amount) VALUES ('$firstname', '$lastname','$emailaddress','$prod_id','$txn_id','$clientdate','$sale_price')";
		$results = $wpdb->query($updatedb);
	}   	
}
?>
