<?php

//**** This file needs to be included from a file that has access to "wp-load.php" ****
include_once('eStore_db_access.php');
include_once('eStore_debug_handler.php');
include_once('eStore_includes4.php');

$infusion_lib_file = "lib/auto-responder/infusionsoft/isdk.php";
$mailchimp_lib_file = "lib/auto-responder/MCAPI.class.php";
$get_response_lib_file = "lib/auto-responder/jsonRPCClient.php";

if (get_option('eStore_enable_infusionsoft_int') == 1)
{
	if (file_exists($infusion_lib_file))
	{
	    include_once($infusion_lib_file);
	}	
}

if(get_option('eStore_use_mailchimp'))
{
	if (file_exists($mailchimp_lib_file))
	{
		if(!class_exists(MCAPI))
		{
	    	include_once($mailchimp_lib_file);
		}
	}	
}

if(get_option('eStore_use_getResponse'))
{
	if(!class_exists(jsonRPCClient))
	{
	   	include_once($get_response_lib_file);
	}
}

function eStore_get_chimp_api_new()
{
    //$api_key = get_option('eStore_chimp_api_key');
    //if(!empty($api_key))
    //{
    //    $api = new MCAPI($api_key);
    //}
    //else
    //{
        $api = new MCAPI(get_option('eStore_chimp_user_name'), get_option('eStore_chimp_pass'));
    //}
    return $api;
}

function eStore_mailchimp_subscribe($api,$target_list_name,$fname,$lname,$email_to_subscribe)
{
    $lists = $api->lists();
    foreach ($lists AS $list) 
    {
        if ($list['name'] == $target_list_name)
        {
            $list_id = $list['id'];
        }
    }
    //echo "<br />List ID: ".$list_id;
    
    $merge_vars = array('FNAME'=>$fname, 'LNAME'=>$lname,
                        'INTERESTS'=>'');

    $retval = $api->listSubscribe( $list_id, $email_to_subscribe, $merge_vars );
    return $retval;
}

function eStore_getResponse_subscribe($campaign_name,$fname,$lname,$email_to_subscribe)
{
	// your API key
	// available at http://www.getresponse.com/my_api_key.html
	$api_key = get_option('eStore_getResponse_api_key');
	
	// API 2.x URL
	$api_url = 'http://api2.getresponse.com';
	
	$customer_name = $fname." ".$lname;
	
	// initialize JSON-RPC client
	$client = new jsonRPCClient($api_url);
	
	$result = NULL;
	
	// get CAMPAIGN_ID of the specified campaign (e.g. 'sample_marketing')
//	try {
//	    $result = $client->get_campaigns(
//	        $api_key,
//	        array (
//	            # find by name literally
//	            'name' => array ( 'EQUALS' => $campaign_name )
//	        )
//	    );
//	}
//	catch (Exception $e) {
//	    # check for communication and response errors
//	    eStore_payment_debug($e->getMessage(),false);
//	}

    $result = $client->get_campaigns(
        $api_key,
        array (
            # find by name literally
            'name' => array ( 'EQUALS' => $campaign_name )
        )
    );

	# uncomment this line to preview data structure
	# print_r($result);
	
	# since there can be only one campaign of this name
	# first key is the CAMPAIGN_ID you need
	$CAMPAIGN_ID = array_pop(array_keys($result));	
	
	if(empty($CAMPAIGN_ID))
	{
		eStore_payment_debug("Could not retrieve campaign ID. Please double check your GetResponse Campaign Name:".$campaign_name,false);
	}
	else
	{
	# add contact to 'sample_marketing' campaign
	//try {
	    $result = $client->add_contact(
	        $api_key,
	        array (
	            'campaign'  => $CAMPAIGN_ID,
	            'name'      => $customer_name,
	            'email'     => $email_to_subscribe
	        )
	    );
//	}
//	catch (Exception $e) {
//	    # check for communication and response errors
//	    eStore_payment_debug($e->getMessage(),false);
//	}
	}
	# uncomment this line to preview data structure
	# print_r($result);	
	//print("Contact added\n");
	return true;
}

//eStore_infusionsoft_signup("Test", "name", "test2@eStore.com", 135);
function eStore_infusionsoft_signup($fname, $lname, $email, $groupId)
{
    $app = new iSDK;
    if ($app->cfgCon("demo")) {
        //echo "Connected...<br />";
    }
    $contact = array('FirstName'=>$fname,
                 'LastName'=>$lname,
                 'Email'=>$email);
    /*
    if (!empty($contact['Email'])) {
        //set up the query
        $qry = array('Email'=>$contact['Email']);
        
        //specify return fields
        $ret = array("Id");
        
        //Execute the query
        $dups = $app->dsQuery("Contact",1,0,$qry,$ret);
        echo "Dup :".$dups;
        
        if (!empty($dups)) {
            //update contact
            $cid = $app->updateCon($dups[0]['Id'],$contact);
        } else {
            //Add new contact
            $cid = $app->addCon($contact);
        }
    }
    */
    $cid = $app->addCon($contact);
    //$cid = $app->addCon($con);
    //echo 'Contact Created/Updated: ' . $cid . '<br />';
    $result = $app->grpAssign($cid, $groupId);
    return $result;
}

function eStore_item_specific_autoresponder_signup($cart_items,$firstname,$lastname,$emailaddress)
{
	eStore_payment_debug('Performing item specific autoresponder signup if specified.',true);
	foreach ($cart_items as $current_cart_item)
	{
		$cart_item_data_num = $current_cart_item['item_number'];
		$cond = " id = '$cart_item_data_num'";
		$retrieved_product = WP_eStore_Db_Access::find(WP_ESTORE_DB_PRODUCTS_TABLE_NAME, $cond);		
	
		// Autoresponder Sign up
	    if (!empty($retrieved_product->aweber_list))
	    {
	    	if(get_option('eStore_use_mailchimp'))//Using Mailchimp
	        {
	        	$api = eStore_get_chimp_api_new();
	            $target_list_name = $retrieved_product->aweber_list;
	            $retval = eStore_mailchimp_subscribe($api,$target_list_name,$firstname,$lastname,$emailaddress);
	            eStore_payment_debug('MailChimp signup operation performed. Return value is: '.$retval,true);
	        }
	        else if(get_option('eStore_use_getResponse'))//Using GetResponse
	        {
	            $campaign_name = $retrieved_product->aweber_list;
	            $retval = eStore_getResponse_subscribe($campaign_name,$firstname,$lastname,$emailaddress);
	            eStore_payment_debug('GetResponse signup operation performed. Return value is: '.$retval,true);	        	
	        }
	        else //Using AWeber
	        {
	        	$download_email = get_option('eStore_download_email_address');
	        	$senders_email = eStore_get_string_between($download_email, "<", ">");
	        	if(empty($senders_email))
	        	{
	        		$senders_email = $download_email;
	        	}
	        	eStore_payment_debug('AWeber signup from email address:'.$senders_email,true);	            
	        	$cust_name = $firstname .' '. $lastname;
	            eStore_send_aweber_mail($retrieved_product->aweber_list,$senders_email,$cust_name,$emailaddress);
	            eStore_payment_debug('AWeber signup operation performed.',true);
	        }
	    }
	}	
}

function eStore_global_autoresponder_signup($firstname,$lastname,$emailaddress)
{
	eStore_payment_debug('Performing global autoresponder signup if specified.',true);
	if (get_option('eStore_enable_aweber_int') == 1)
    {
    	$download_email = get_option('eStore_download_email_address');
    	$aweber_list = get_option('eStore_aweber_list_name');
        $cust_name = $firstname .' '. $lastname;
        eStore_send_aweber_mail($aweber_list,$download_email,$cust_name,$emailaddress);
        eStore_payment_debug('AWeber signup email sent.',true);
    }
    if (get_option('eStore_enable_global_chimp_int') == 1)
    {
        $api = eStore_get_chimp_api_new();
        $target_list_name = get_option('eStore_chimp_list_name');
        $retval = eStore_mailchimp_subscribe($api,$target_list_name,$firstname,$lastname,$emailaddress);
        eStore_payment_debug('MailChimp signup operation performed. Return value is: '.$retval,true);
    }
    if(get_option('eStore_enable_global_getResponse_int') == 1)
    {
	    $campaign_name = get_option('eStore_getResponse_campaign_name');
	    $retval = eStore_getResponse_subscribe($campaign_name,$firstname,$lastname,$emailaddress);
	    eStore_payment_debug('GetResponse signup operation performed. Return value is: '.$retval,true);	      	
    }
    if (get_option('eStore_enable_infusionsoft_int') == 1)
    {
         $groupId = get_option('eStore_infusionsoft_group_number');
         $result = eStore_infusionsoft_signup($firstname, $lastname, $emailaddress, $groupId);
         eStore_payment_debug('Infusionsoft signup result: '.$result,true);
    } 	
}
?>