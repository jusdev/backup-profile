<?php
function eStore_admin_css()
{
    ?>
    <style type="text/css">
    .msg_head {
    padding: 5px 10px;
    cursor: pointer;
    position: relative;
    font-size: 12px;
    font-weight: bold;
    color:#288CD6;
    background-color:#E2E2E2;
    border:1px solid #DAD9D8;
    margin-top: 15px;
    padding-left:25px;
    background-image: url('<?php echo WP_ESTORE_URL; ?>/images/estore_plus_icon.png');
    background-repeat: no-repeat;
    background-position: 2px 2px;
    }
    .msg_head:hover{
    background-color:#CACACA;
    }
    .msg_body {
    padding: 5px 10px 15px;
    background-color:#F4F4F8;
    border:1px solid #C2C2CF;
    }
    .section_head {
    padding: 5px 10px;
    position: relative;
    font-size: 12px;
    margin-bottom: 15px;
    background-color:#E9E9E9;
    border:1px solid #D5D8D9;
    }
    </style>
    <?php
}
function eStore_admin_submenu_css()
{
	?>
	<style type="text/css">
	.eStoreSubMenu{
	list-style:none;
	margin:0 0 5px 0;
	padding:0;
	height:2em;
	font-size:14px;
	clear:both;
	background:#ECECEC none repeat scroll 0 0;
	}

	.eStoreSubMenu li{
	float:left;
	padding:0;
	margin:0;
	}

	.eStoreSubMenu li a{
	display:block;
	float:left;
	margin:0 0 0 12px;
	padding:0 5px;
	text-decoration:none;
	line-height:200%;
	}
	.eStoreSubMenu li.current{
     border-top:2px solid #ECECEC;
     background:#F9F9F9;
	}
	</style>
	<?php
}

function eStore_admin_js_scripts()
{
    $output = '
    <script type="text/javascript">
    $(document).ready(function()
    {
      //hide the all of the element with class msg_body
      $(".msg_body").hide();
      //toggle the componenet with class msg_body
      $(".msg_head").click(function()
      {
        $(this).next(".msg_body").animate({ "height": "toggle", "opacity": "toggle" });
      });
    });
    </script>';
    return $output;
}
function eStore_admin_datepicker_js()
{
?>
<script type="text/javascript">
jQuery(document).ready(function($) {
    $(function() {
        var imgPath = '<?php echo get_option('siteurl').'/wp-content/plugins/'.
        dirname(plugin_basename(__FILE__)) . '/images/' ;?>';
		jQuery('#stat_start_date').datepicker({dateFormat: 'yy-mm-dd' ,showOn: 'button', buttonImage: imgPath+'calendar.gif', buttonImageOnly: true}).dateEntry({dateFormat: 'ymd-',spinnerImage: '', useMouseWheel:false});
		jQuery('#stat_end_date').datepicker({dateFormat: 'yy-mm-dd' ,showOn: 'button', buttonImage: imgPath+'calendar.gif', buttonImageOnly: true}).dateEntry({dateFormat: 'ymd-',spinnerImage: '', useMouseWheel:false});
    });
});
</script>	
<?php 
}

function wp_eStore_load_jquery()
{
    return '<script type="text/javascript" src="'.WP_ESTORE_URL.'/lib/jquery.js"></script>';
}
function wp_eStore_load_date_entry_js()
{
    return '<script type="text/javascript" src="'.WP_ESTORE_URL.'/lib/jquery.dateentry.pack.js"></script>';
}

?>