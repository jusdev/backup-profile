<?php
	//Simple Google Maps results crawler 
	//============================================================
	function mapcrawl($location)
	{
		//Format location string with proper URL and +'s
   		$location = "http://maps.google.com/maps?q=".str_replace(" ","+",$location);
		
		if(!$fp = fopen($location,"r" )) {
        	return false;
    	} //our fopen is right, so let's go
	
    	$site = "";
	   	while(!feof($fp)) { //while it is not the last line, we will add the current line to our $content
        	$site .= fgets($fp, 1024);
    	}
    	fclose($fp);  //we are done here, don't need the main source anymore
    	
		return $site; //return crawled map	
	}
	
	//Get the lat,long from the crawled site by stripping excess HTML code and return just the lat,long
	//============================================================
	function stripll($site)
	{
		$ll = substr($site,strpos($site,"ll=")+3);
		$ll = substr($ll,0,18);
		return $ll;
	}	
	
	
	//Display information and return lat,long in an array
	//============================================================
	function showinfo($latlong,$location)
	{
		echo "Location  : ".$location."<br />";
		
		//check for just city and state or just state/City
		if (substr($latlong,0,6) != 'OCTYPE') {
			echo "(Lat,Long): (".$latlong.") <br />";
		}
		else{
			echo "(Lat,Long): Not Available <br />";
		}
		
		//show map
		echo '<iframe width="500" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q='.$location.'&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe>';
		
		//return the lat,long in array form
		$comma = strpos($latlong,",");
		return array(substr($latlong,0,$comma),substr($latlong,$comma));	
	}


	//Main code 
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
		 
	//set variable to location of desired place lat, long is needed
	//$location = "cort theatre new york, NY";
	//$location = "rams head live baltimore Md";
	//$location = "Wichita Falls, TX";
	//$location = "3118 Seymour Hwy, Wichita Falls, TX";
	//$location = "Texas";
	$location = "Miami";
	
  	//strip excess HTML and leave behind the lat,long coords
  	$content = mapcrawl($location);
	$latlong = stripll($content);
	
	//if crawled page has (lat,long) echo, else search via address on page
	if ((substr($latlong,0,6) != 'OCTYPE') || (substr($latlong,0,8) != 'Location')) {
		//display info and save data	
		$coords = showinfo($latlong,$location);
	}
	else
	{
		//"pp-headline-item pp-headline-address"" is a unique css tag for the first address
		//strip excess HTML and leave behind the the locations address
		$location = substr($content,strpos($content,"pp-headline-item pp-headline-address")+44);
		$location = substr($location,0,strpos($location,"</span>"));
		
		//recrawl based on new physical address of location
		$content = mapcrawl($location);
		$latlong = stripll($content);
				
		//display info and save data
		$coords = showinfo($latlong,$location);
	}
?>
